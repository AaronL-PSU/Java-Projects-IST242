/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectanglemovertimer;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author tkc3
 */
public class RectangleFrame extends JFrame {

    private RectangleComponent rc;
    private RectangleComponent rc2;
    private ActionListener listener;

    public RectangleFrame() {

        rc = new RectangleComponent();
        add(rc);
        setSize(250, 250);
        
        rc2 = new RectangleComponent();
        add(rc2);
        setSize(250, 250);
        
        listener = new TimerListener();
        Timer t = new Timer(10, listener);
        t.start();
    }

    class TimerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            rc.moveBy(1, 1);
            rc2.moveBy(2, 2);
        }
    }

}
