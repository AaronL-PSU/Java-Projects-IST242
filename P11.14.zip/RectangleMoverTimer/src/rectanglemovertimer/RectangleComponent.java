/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectanglemovertimer;

import java.awt.Graphics;
import javax.swing.JComponent;

public class RectangleComponent extends JComponent {

    private int xpos;
    private int ypos;
    private final static int WIDTH = 50;
    private final static int HEIGHT = 30;

    public RectangleComponent() {
        xpos = 0;
        ypos = 0;
    }

    public void paintComponent(Graphics g) {
        g.fillRect(xpos, ypos, WIDTH, HEIGHT);
    }

    // This one is for the Timer activity
    public void moveBy(int dx, int dy) {
        xpos += dx;
        ypos += dy;
        repaint();
    }

    // This one is for the Mouse Events activity
    public void moveTo(int x, int y) {
        xpos = x;
        ypos = y;
        repaint();
    }

}
