/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circlemovermouse;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class MouseFrame extends JFrame {

    private CircleComponent crc;
    private JRadioButton Button10;
    private JRadioButton Button20;
    private JRadioButton Button30;

    public MouseFrame() {
        crc = new CircleComponent();
        add(crc);
        setSize(500, 500);

        Button10 = new JRadioButton("10");
        Button10.setSelected(true);
        Button20 = new JRadioButton("20");
        Button30 = new JRadioButton("30");
        
        ButtonGroup group = new ButtonGroup();
        group.add(Button10);
        group.add(Button20);
        group.add(Button30);
        
        ActionListener listener = new ButtonListener();
        Button10.addActionListener(listener);
        Button20.addActionListener(listener);
        Button30.addActionListener(listener);

    }

    class ButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if (Button10.isSelected()){
                crc.changeSize(10);
            }
            else if (Button20.isSelected()){
                crc.changeSize(20);
            }
            else if (Button30.isSelected()){
                crc.changeSize(30);
            }
        }
    }

}
