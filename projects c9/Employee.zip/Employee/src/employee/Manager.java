/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Aaron
 */
public class Manager extends Employee{
    protected String department;
    public void print(){
        name="bob";
        salary="11111";
        department="test";
        System.out.println(department.toString());
        System.out.println(name.toString());
        System.out.println(salary.toString());
    }
}
