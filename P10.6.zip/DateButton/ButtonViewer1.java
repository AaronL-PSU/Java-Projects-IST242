package buttonviewer1;

import javax.swing.JFrame;

public class ButtonViewer1 {

    public static void main(String[] args) {
       JFrame frame = new ButtonFrame();
      
        frame.setTitle("My Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
 
}
}
