/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author Aaron
 */
public class SnowManFrame extends JFrame{
    private SnowManComponent comp;
    private JRadioButton ButtonD;
    private JRadioButton ButtonN;
    private JComboBox hatCombo;
    
    public SnowManFrame(){
        comp = new SnowManComponent(); //Initialize Snowman component
        setLayout(new BorderLayout()); //Border layout for JFrame
        add(comp,BorderLayout.CENTER); //Adds Snowman component to center of JFrame
        JPanel panel = new JPanel();
        
        ButtonD = new JRadioButton("Day"); //Create radio buttons
        ButtonD.setSelected(true);
        ButtonN = new JRadioButton("Night");
        
        ButtonGroup group = new ButtonGroup(); //Create button group
        group.add(ButtonD);
        group.add(ButtonN);
        
        panel.add(ButtonD); //Add buttons to panel
        panel.add(ButtonN);
        
        ActionListener blistener = new ButtonListener(); //Radio button listener
        ButtonD.addActionListener(blistener);
        ButtonN.addActionListener(blistener);
        
        JLabel hatLabel = new JLabel("Hat Color: "); //Create hat color label
        panel.add(hatLabel);
        
        hatCombo = new JComboBox(); //Create hat color combobox
        hatCombo.addItem("Red");
        hatCombo.addItem("Green");
        hatCombo.addItem("Blue");
        hatCombo.setEditable(false);
        ActionListener clistener = new ComboListener(); //Combobox listener
        hatCombo.addActionListener(clistener);
        panel.add(hatCombo);

        add(panel,BorderLayout.SOUTH); //Add GUI panel to south
    }

    class ButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if (ButtonD.isSelected()) {
                comp.skyDay();
            } 
            else if (ButtonN.isSelected()) {
              comp.skyNight();
        }
    }
        
    }
    class ComboListener implements ActionListener{
         public void actionPerformed(ActionEvent e) {
             
           if(hatCombo.getSelectedItem().equals("Red")){
             comp.hatRed();
           }
           else if(hatCombo.getSelectedItem().equals("Green")){
             comp.hatGreen();
         }
           else if(hatCombo.getSelectedItem().equals("Blue")){
             comp.hatBlue();
         }
           
         }
    }
}
