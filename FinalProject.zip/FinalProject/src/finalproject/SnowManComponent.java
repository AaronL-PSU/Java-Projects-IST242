/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

/**
 *
 * @author Aaron
 */
public class SnowManComponent extends JComponent{
    public Color bgColor = Color.CYAN; //Colors initialized to default button options
    public Color hatColor = Color.RED;
    final Color Brown= new Color(205, 127, 50);
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(3));
        
        g.setColor(bgColor); //Background
        g.fillRect(0, 0, 425, 350);
        
        g.setColor(Color.WHITE); //Bottom
        g.fillOval(180,220,90,90);
        
        g.setColor(Color.WHITE); //Middle
        g.fillOval(190,166,70,70);
        
        g.setColor(Color.WHITE); //Head
        g.fillOval(200,126,50,50);
        
        g.setColor(Color.BLACK); //Bottom Button
        g.fillOval(218,195,15,15);
        
        g.setColor(Color.BLACK); //Middle Buton
        g.fillOval(218,255,15,15);
        
        g.setColor(Brown);
        g.fillRect(260,200,40,5); //Right Arm
        
        g.setColor(Brown);
        g.fillRect(295,170,5,35); //Right Forearm
        
        g.setColor(Brown);
        g.fillRect(150,200,40,5); //Left Arm
        
        g.setColor(Brown);
        g.fillRect(150,170,5,35); //Left Forearm
        
        g.setColor(Brown); //Left Bicep
        g.fillOval(158, 192, 30, 25);
        
        g.setColor(bgColor); //Left Bicep Cover
        g.fillRect(158, 205, 30, 20);
        
        g.setColor(Brown); //Right Bicep
        g.fillOval(262, 192, 30, 25);
        
        g.setColor(bgColor); //Right Bicep Cover
        g.fillRect(262, 205, 30, 20);
        
        g.setColor(Color.BLACK); //Mouth
        g.fillRect(215, 160, 20, 3);
        
        g.setColor(Color.ORANGE); //Nose Bottom
        g.drawLine(225, 155, 238, 150);
       
        g.setColor(Color.ORANGE); //Nose Top
        g.drawLine(225, 145, 238, 150);
        
        g.setColor(Color.BLACK); //Right Eye
        g.fillOval(232, 140, 5, 5);
        
        g.setColor(Color.BLACK); //Left Eye
        g.fillOval(210, 140, 5, 5);
        
        g.setColor(Color.BLACK); //Right Eyebrow
        g.drawLine(230, 140, 238, 137);
        
        g.setColor(Color.BLACK); //Left Eyebrow
        g.drawLine(210, 137, 218, 140);
        
        g.setColor(hatColor); //Hat Brim
        g.fillRect(195, 127, 60, 8);
        
        g.setColor(Color.BLACK); //Hat Middle
        g.fillRect(205, 110, 40, 17);
        
        g.setColor(hatColor); //Hat Top
        g.fillRect(205, 90, 40, 20);
        
        g.setColor(Color.WHITE); //Button Area
        g.fillRect(0, 320, 425, 50);
        
        g.setFont(new Font("TimesRoman", Font.BOLD, 30));
        g2.drawString("Chad the Snowman", 50, 70); //Name
    }
    public void skyDay(){
        bgColor=Color.CYAN;
        repaint();
    }
     public void skyNight(){
        bgColor=Color.DARK_GRAY;
        repaint();
    }
     public void hatRed(){
         hatColor=Color.RED;
         repaint();
     }
     public void hatGreen(){
         hatColor=Color.GREEN;
         repaint();
     }
    public void hatBlue(){
         hatColor=Color.BLUE;
         repaint();
     }

}
