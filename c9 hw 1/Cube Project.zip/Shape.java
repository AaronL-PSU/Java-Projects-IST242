/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cube;

/**
 *
 * @author Aaron
 */
public class Shape {
    protected double volume;
    
    public static void main(String[] args){
        Cone newCone = new Cone();
        System.out.println(newCone.calcVolume());
}
}
