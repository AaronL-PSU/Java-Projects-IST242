/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circlemovermouse;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;

public class MouseFrame extends JFrame {

    private CircleComponent crc;
    private MouseListener listener;

    public MouseFrame() {
        crc = new CircleComponent();
        add(crc);
        setSize(500, 500);

        listener = new MousePressedListener();
        crc.addMouseListener(listener);

    }

    class MousePressedListener implements MouseListener {

        public void mouseClicked(MouseEvent e) {
            int newx = e.getX();
            int newy = e.getY();
            crc.moveTo(newx, newy);
        }

        public void mousePressed(MouseEvent e) {
        }

        public void mouseReleased(MouseEvent e) {
        }

        public void mouseEntered(MouseEvent e) {
        }

        public void mouseExited(MouseEvent e) {
        }

    }

}
