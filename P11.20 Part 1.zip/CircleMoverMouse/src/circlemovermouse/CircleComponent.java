/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circlemovermouse;

import java.awt.Graphics;

/**
 *
 * @author Aaron
 */
public class CircleComponent {
    private int xpos;
    private int ypos;
    private final static int radius = 20;

    public CircleComponent() {
        xpos = 0;
        ypos = 0;
    }

    public void paintComponent(Graphics g) {
        g.drawOval(xpos, ypos, radius * 2, radius * 2);
    }
    // This one is for the Mouse Events activity
    public void moveTo(int x, int y) {
        xpos = x;
        ypos = y;
        repaint();
    }

}
